import json
import jwt
import time
import requests
from cryptography.hazmat.primitives import serialization

# === CREDENTIALS FROM YOUR JSON FILE ===
API_KEY_NAME = "organizations/your-org-id/apiKeys/your-key-id"

PRIVATE_KEY_PEM = """-----BEGIN EC PRIVATE KEY-----
\nMHcCAQEEIA...==\n
-----END EC PRIVATE KEY-----"""


def validate_private_key_format(private_key_pem):
    """
    Validate and diagnose private key format issues
    """
    print("🔍 Diagnosing private key format...")
    
    # Check basic structure
    lines = private_key_pem.strip().split('\n')
    print(f"   → Key has {len(lines)} lines")
    
    if len(lines) < 3:
        print("   ❌ Key appears too short")
        return False
    
    # Check headers
    if not lines[0].strip().startswith('-----BEGIN'):
        print("   ❌ Missing BEGIN header")
        return False
        
    if not lines[-1].strip().startswith('-----END'):
        print("   ❌ Missing END header")
        return False
    
    print(f"   → Begin: {lines[0].strip()}")
    print(f"   → End: {lines[-1].strip()}")
    
    # Check if headers match
    if 'EC PRIVATE KEY' in lines[0] and 'EC PRIVATE KEY' in lines[-1]:
        print("   ✅ EC Private Key headers look correct")
    elif 'PRIVATE KEY' in lines[0] and 'PRIVATE KEY' in lines[-1]:
        print("   ⚠️  Generic PRIVATE KEY format (should work)")
    else:
        print("   ❌ Header mismatch or incorrect format")
        return False
    
    # Check key data
    key_data_lines = [line.strip() for line in lines[1:-1] if line.strip()]
    total_key_length = sum(len(line) for line in key_data_lines)
    print(f"   → Key data: {len(key_data_lines)} lines, {total_key_length} characters")
    
    if total_key_length < 50:
        print("   ❌ Key data appears too short")
        return False
    
    # Check for invalid characters
    import base64
    try:
        combined_data = ''.join(key_data_lines)
        base64.b64decode(combined_data, validate=True)
        print("   ✅ Key data is valid base64")
    except Exception as e:
        print(f"   ❌ Invalid base64 data: {e}")
        return False
    
    return True

def create_coinbase_jwt(request_method, request_path, api_key_name, private_key_pem):
    """
    Create a JWT token for Coinbase Advanced Trade API with correct format
    Based on official Coinbase CDP documentation
    """
    try:
        # First validate the key format
        if not validate_private_key_format(private_key_pem):
            print("❌ Private key format validation failed")
            return None
        
        # Try different key loading methods
        print("🔧 Attempting to load private key...")
        
        # Method 1: Standard EC private key
        try:
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode('utf-8'),
                password=None
            )
            print("   ✅ Loaded as EC private key")
        except Exception as e1:
            print(f"   ❌ EC private key failed: {e1}")
            
            # Method 2: Try with different encoding
            try:
                private_key = serialization.load_pem_private_key(
                    private_key_pem.strip().encode('utf-8'),
                    password=None
                )
                print("   ✅ Loaded with stripped encoding")
            except Exception as e2:
                print(f"   ❌ Stripped encoding failed: {e2}")
                
                # Method 3: Try to fix common formatting issues
                try:
                    # Remove any extra whitespace and normalize line endings
                    cleaned_key = '\n'.join(line.strip() for line in private_key_pem.strip().split('\n') if line.strip())
                    private_key = serialization.load_pem_private_key(
                        cleaned_key.encode('utf-8'),
                        password=None
                    )
                    print("   ✅ Loaded with cleaned formatting")
                except Exception as e3:
                    print(f"   ❌ All loading methods failed")
                    print(f"   → Original error: {e1}")
                    print(f"   → Stripped error: {e2}")  
                    print(f"   → Cleaned error: {e3}")
                    return None
        
        # Format the URI exactly as Coinbase expects
        uri = f"{request_method} api.coinbase.com{request_path}"
        
        # Get current timestamp
        now = int(time.time())
        
        # Create JWT payload with correct structure
        payload = {
            "sub": api_key_name,          # Subject: your API key name  
            "iss": "cdp",                 # Issuer: always "cdp" for Coinbase
            "nbf": now,                   # Not before: current time
            "exp": now + 120,             # Expires: 2 minutes from now
            "aud": ["cdp_service"],       # Audience: CDP service
            "uri": uri                    # Request URI
        }
        
        # Create JWT header with correct algorithm
        headers = {
            "alg": "ES256",
            "typ": "JWT",
            "kid": api_key_name          # Key ID should be the full API key name
        }
        
        print(f"🔧 Creating JWT for: {uri}")
        print(f"🔧 Key ID: {api_key_name}")
        print(f"🔧 Timestamp: {now}")
        
        # Create and return the JWT token with explicit headers
        token = jwt.encode(
            payload, 
            private_key, 
            algorithm="ES256",
            headers=headers
        )
        
        return token
        
    except Exception as e:
        print(f"❌ Error creating JWT token: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_coinbase_endpoint(method, path, label):
    """
    Test a specific Coinbase endpoint with proper JWT authentication
    """
    print(f"   ▶ Testing: {label}")
    
    # Create JWT token specifically for this endpoint
    token = create_coinbase_jwt(method, path, API_KEY_NAME, PRIVATE_KEY_PEM)
    if not token:
        print(f"   ❌ Failed to create JWT token for {label}")
        return False
    
    # Debug: Print first 50 chars of token
    print(f"   🔧 JWT token (first 50 chars): {str(token)[:50]}...")
    
    # Make the API request
    url = f"https://api.coinbase.com{path}"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
        'User-Agent': 'CoinbaseAdvancedTradeAPI/1.0'
    }
    
    try:
        if method == "GET":
            response = requests.get(url, headers=headers, timeout=30)
        elif method == "POST":
            response = requests.post(url, headers=headers, json={}, timeout=30)
        else:
            print(f"   ❌ Unsupported method: {method}")
            return False
        
        print(f"   🔧 Response status: {response.status_code}")
        print(f"   🔧 Response headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            print(f"   ✅ SUCCESS! {label} works!")
            try:
                data = response.json()
                if 'accounts' in data:
                    accounts = data['accounts']
                    print(f"   → Found {len(accounts)} account(s)")
                    for i, account in enumerate(accounts[:2]):
                        currency = account.get('currency', 'Unknown')
                        balance = account.get('available_balance', {}).get('value', '0')
                        print(f"   → Account {i+1}: {currency} (Balance: {balance})")
                elif 'products' in data:
                    products = data['products']
                    print(f"   → Found {len(products)} product(s)")
                    for i, product in enumerate(products[:3]):
                        print(f"   → Product {i+1}: {product.get('product_id', 'Unknown')}")
                elif 'data' in data:
                    print(f"   → Data received: {type(data['data'])}")
                else:
                    print(f"   → Valid response received")
                    print(f"   → Keys in response: {list(data.keys())}")
            except Exception as e:
                print(f"   → Valid response (parse error: {e})")
            return True
        elif response.status_code == 401:
            print(f"   ❌ Unauthorized (401) - JWT token rejected")
            print(f"   → Response: {response.text[:200]}")
            return False
        elif response.status_code == 403:
            print(f"   ❌ Forbidden (403) - Insufficient permissions")
            print(f"   → Response: {response.text[:200]}")
            return False
        elif response.status_code == 404:
            print(f"   ❌ Not Found (404) - Endpoint may not exist")
            return False
        else:
            print(f"   ❌ Error {response.status_code}: {response.text[:200]}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Request Exception: {e}")
        return False
    except Exception as e:
        print(f"   ❌ Unexpected Exception: {e}")
        return False

def validate_jwt_creation():
    """
    Test JWT creation with debug information
    """
    print("🔍 Testing JWT creation...")
    
    test_method = "GET"
    test_path = "/api/v3/brokerage/accounts"
    
    token = create_coinbase_jwt(test_method, test_path, API_KEY_NAME, PRIVATE_KEY_PEM)
    
    if token:
        print("✅ JWT token created successfully")
        
        # Decode and display token contents (for debugging)
        try:
            # Note: This will fail signature verification, but we can see the payload
            decoded = jwt.decode(token, options={"verify_signature": False})
            print(f"🔧 JWT Payload: {json.dumps(decoded, indent=2)}")
            
            # Check token structure
            parts = str(token).split('.')
            print(f"🔧 JWT has {len(parts)} parts (should be 3)")
            
        except Exception as e:
            print(f"🔧 Could not decode JWT for inspection: {e}")
            
        return True
    else:
        print("❌ Failed to create JWT token")
        return False

def fix_key_format_issues():
    """
    Try to fix common private key format issues
    """
    print("🔧 Attempting to fix key format issues...")
    print()
    print("Please check your private key and try these fixes:")
    print()
    print("1. **Complete Key Check**: Ensure you copied the COMPLETE key including:")
    print("   -----BEGIN EC PRIVATE KEY-----")
    print("   [all the base64 data lines]")
    print("   -----END EC PRIVATE KEY-----")
    print()
    print("2. **Format Issues**: Your key should look like this:")
    print("   -----BEGIN EC PRIVATE KEY-----")
    print("   MHcCAQEEI...")
    print("   (more lines)")
    print("   -----END EC PRIVATE KEY-----")
    print()
    print("3. **Copy/Paste Issues**: ")
    print("   → Make sure no extra spaces or characters were added")
    print("   → Check for line break issues")
    print("   → Ensure the key wasn't truncated during copy/paste")
    print()
    
    # Let's try to analyze the current key
    print("4. **Current Key Analysis**:")
    lines = PRIVATE_KEY_PEM.strip().split('\n')
    for i, line in enumerate(lines):
        if i == 0 or i == len(lines) - 1:
            print(f"   Line {i+1}: {line}")
        else:
            print(f"   Line {i+1}: {line[:20]}... ({len(line)} chars)")
    print()
    
    # Suggest a cleaned version
    print("5. **Cleaned Version to Try**:")
    cleaned_lines = [line.strip() for line in lines if line.strip()]
    cleaned_key = '\n'.join(cleaned_lines)
    print('PRIVATE_KEY_PEM = """' + cleaned_key + '"""')

def validate_coinbase_api():
    """
    Test multiple Coinbase endpoints with proper JWT authentication
    """
    print("🔍 Testing Coinbase API endpoints...")
    print()
    
    # First test JWT creation
    if not validate_jwt_creation():
        print()
        fix_key_format_issues()
        return False
    
    print()
    
    # Test endpoints - start with most permissive ones
    endpoints = [
        ("GET", "/api/v3/brokerage/products", "Advanced Trade - Products (Public)"),
        ("GET", "/api/v3/brokerage/accounts", "Advanced Trade - Accounts"),
        ("GET", "/api/v3/brokerage/portfolios", "Advanced Trade - Portfolios"),
    ]
    
    success_count = 0
    
    for method, path, label in endpoints:
        if test_coinbase_endpoint(method, path, label):
            success_count += 1
            break  # Stop on first success
        print()  # Add spacing between tests
    
    return success_count > 0

def install_requirements():
    """Install required packages"""
    import subprocess
    import sys
    
    packages = ['PyJWT[crypto]', 'cryptography', 'requests']
    
    print("📦 Installing packages...")
    for package in packages:
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '-q'])
            print(f"✅ {package}")
        except subprocess.CalledProcessError:
            print(f"❌ Failed: {package}")

def check_system_time():
    """Check if system time is reasonable"""
    import datetime
    now = datetime.datetime.now()
    print(f"🕐 System time: {now}")
    
    # Check if time is reasonable (not too far in past/future)
    if now.year < 2024 or now.year > 2026:
        print("⚠️  WARNING: System time seems incorrect - this can cause JWT failures")
        return False
    return True

# === MAIN EXECUTION ===
if __name__ == "__main__":
    print("🔐 Coinbase CDP API Validator (FIXED VERSION)")
    print("=" * 60)
    
    install_requirements()
    print()
    
    print("🔑 Credentials loaded:")
    print(f"   API Key: ...{API_KEY_NAME.split('/')[-1]}")
    print("   Private Key: ✅ Loaded")
    print()
    
    check_system_time()
    print()
    
    print("🚀 Testing API authentication...")
    print("-" * 60)
    
    success = validate_coinbase_api()
    
    print()
    print("=" * 60)
    if success:
        print("🎉 SUCCESS! Your Coinbase CDP API key is VALID and working!")
        print("✅ Authentication successful - you can use this key for API calls")
    else:
        print("❌ VALIDATION FAILED - All endpoints returned errors")
        print()
        print("🔍 Common Issues & Solutions:")
        print("   1. API Key Status:")
        print("      → Check Coinbase Developer Console")
        print("      → Ensure API key status is 'Active'")
        print("      → Verify the key hasn't been revoked")
        print()
        print("   2. Permissions:")
        print("      → API key needs 'view' permission for accounts")
        print("      → Check Advanced Trade API permissions are enabled")
        print()
        print("   3. Key Format:")
        print("      → Ensure private key is in correct PEM format")
        print("      → Verify the private key matches the API key")
        print()
        print("   4. System Issues:")
        print("      → Check system time is correct (JWT is time-sensitive)")
        print("      → Ensure internet connection is stable")
        print()
        print("🔧 Next Steps:")
        print("   • Visit: https://portal.cdp.coinbase.com/")
        print("   • Check API key status and permissions")
        print("   • Try regenerating the API key if needed")